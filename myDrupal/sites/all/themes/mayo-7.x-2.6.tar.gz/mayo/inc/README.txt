The responsive layout structure is adapted from the AdaptiveTheme project by
Jeff Burnz. https://drupal.org/project/adaptivetheme
