
About mayo.js in this directory
===============================
The javascript file mayo-fontsize.js is only loaded and used when you select to add font resizing control to the header area.
The javascript file mayo-columns.js is only loaded and used when top block columns or bottom block columns are used.

